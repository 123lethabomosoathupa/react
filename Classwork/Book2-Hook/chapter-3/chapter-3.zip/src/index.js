// Import React library (required when using JSX)
import React from 'react';

// Import ReactDOM to render React components to the DOM
import ReactDOM from 'react-dom';

// Import global CSS styles for the application
import './index.css';

// Import the main App component
import App from './App';

// Import service worker functions for offline capabilities
import * as serviceWorker from './serviceWorker';

// Import Bootstrap CSS for styling and responsive design
import 'bootstrap/dist/css/bootstrap.min.css';

// Render the App component into the root div in index.html
ReactDOM.render(
  // StrictMode helps identify potential problems in the app during development
  <React.StrictMode>
    <App />
  </React.StrictMode>,

  // Target the HTML element with id="root"
  document.getElementById('root')
);

// Unregister the service worker (app will not work offline)
serviceWorker.unregister();
