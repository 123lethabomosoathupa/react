import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ReactLoading from 'react-loading';
import { Card, ListGroup } from 'react-bootstrap'; // Changed from Media

function GitHub() {
  const [data, setData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    getData();
  }, []); // Empty dependency array

  const getData = async () => {
    const res = await axios.get(`https://api.github.com/search/users?q=${searchTerm || 'greg'}`);
    setData(res.data.items);
    setIsLoading(false);
  };

  const handleSubmit = event => {
    event.preventDefault();
    setIsLoading(true);
    getData();
  };

  const listUsers = data.map((user) => (
    <ListGroup.Item key={user.id} className="d-flex align-items-center">
      <a href={user.html_url} target="_blank" rel="noopener noreferrer">
        <img
          width={64}
          height={64}
          className="me-3 rounded"
          src={user.avatar_url}
          alt={user.login}
        />
      </a>
      <div>
        <h5 className="mb-1">Login: {user.login}</h5>
        <p className="mb-0">Id: {user.id}</p>
      </div>
    </ListGroup.Item>
  ));

  return (
    <div className="container mt-4">
      <form onSubmit={handleSubmit} className="mb-4">
        <div className="input-group">
          <input
            type="text"
            className="form-control"
            placeholder="Search GitHub users..."
            onChange={event => setSearchTerm(event.target.value)}
            value={searchTerm}
          />
          <button type="submit" className="btn btn-primary">Search</button>
        </div>
      </form>

      <h3>GitHub Users Results</h3>
      
      {isLoading && (
        <div className="d-flex justify-content-center my-4">
          <ReactLoading type="spinningBubbles" color="#444" />
        </div>
      )}
      
      <ListGroup>
        {listUsers}
      </ListGroup>
    </div>
  );
}

export default GitHub;