import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import GitHub from './GitHub';

function App() {
  return (
    <div className="container mt-5">
      <GitHub />
    </div>
  );
}

export default App;