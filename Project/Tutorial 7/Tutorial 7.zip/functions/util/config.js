module.exports = {
    apiKey: "AIzaSyDMugfPRlJ9-rX4J1xi9hnvcwHKkVr6a14",
  authDomain: "todolist-fc678shd.firebaseapp.com",
  databaseURL: "https://todolist-fc678shd-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "todolist-fc678shd",
  storageBucket: "todolist-fc678shd.firebasestorage.app",
  messagingSenderId: "889284919596",
  appId: "1:889284919596:web:8ba35004553cd8a2882c89"
};