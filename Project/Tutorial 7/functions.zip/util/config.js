module.exports = {
   apiKey: "AIzaSyC1aP35ayp_R0v9Yd-ImvPCo_CyUaVYbNs",
  authDomain: "todolist-ead06.firebaseapp.com",
  databaseURL: "https://todolist-ead06-default-rtdb.firebaseio.com",
  projectId: "todolist-ead06",
  storageBucket: "todolist-ead06.firebasestorage.app",
  messagingSenderId: "926710224220",
  appId: "1:926710224220:web:574ac65d9d55763831dd99",
  measurementId: "G-9JMWPBV2ZS"
};
